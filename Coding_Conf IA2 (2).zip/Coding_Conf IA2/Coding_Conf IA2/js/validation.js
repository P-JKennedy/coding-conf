// This file checks the form and saves the details for the ticket page.
const form = document.getElementById("registration-form");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  // Clear any errors from the last attempt.
  document.querySelectorAll(".error").forEach(function (message) {
    message.textContent = "";
  });

  const name = document.getElementById("fullName").value.trim();
  const email = document.getElementById("email").value.trim();
  const github = document.getElementById("github").value.trim();
  const avatar = document.getElementById("avatar").files[0];
  let valid = true;

  if (name === "") {
    document.getElementById("nameError").textContent = "Please enter your full name.";
    valid = false;
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    document.getElementById("emailError").textContent = "Please enter a valid email.";
    valid = false;
  }

  if (!/^@[A-Za-z0-9-]+$/.test(github)) {
    document.getElementById("githubError").textContent = "Start your GitHub username with @.";
    valid = false;
  }

  if (!avatar) {
    document.getElementById("avatarError").textContent = "Please choose a profile picture.";
    valid = false;
  } else if (avatar.type !== "image/jpeg" && avatar.type !== "image/png") {
    document.getElementById("avatarError").textContent = "Choose a JPEG or PNG image.";
    valid = false;
  } else if (avatar.size >= 500 * 1024) {
    document.getElementById("avatarError").textContent = "Your image must be under 500KB.";
    valid = false;
  }

  if (!valid) return;

  // Read the chosen picture so it can appear on the ticket.
  const reader = new FileReader();
  reader.onload = function () {
    const details = {
      name: name,
      email: email,
      github: github,
      avatar: reader.result
    };
    localStorage.setItem("codingConfDetails", JSON.stringify(details));
    window.location.href = "ticket.html";
  };
  reader.readAsDataURL(avatar);
});
