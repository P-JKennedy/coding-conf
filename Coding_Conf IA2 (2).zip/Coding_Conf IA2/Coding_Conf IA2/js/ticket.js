// Load the saved registration details and display them on the ticket.
const savedDetails = localStorage.getItem("codingConfDetails");

if (!savedDetails) {
  // Go back to the home page if no one has registered.
  window.location.href = "index.html";
} else {
  const details = JSON.parse(savedDetails);
  document.getElementById("ticketName").textContent = details.name;
  document.getElementById("cardName").textContent = details.name;
  const githubLink = document.getElementById("cardGithub");
  githubLink.textContent = details.github;
  githubLink.href = "https://github.com/" + details.github.substring(1);
  document.getElementById("ticketAvatar").src = details.avatar;
}
