CODING CONF — REQUIREMENT-CHECKED BEGINNER VERSION

Project structure:
- HTML/: index.html, login.html, ticket.html
- css/style.css
- js/validation.js, js/ticket.js
- assets/images/: image assets used by the pages
- reference/: original assignment brief, style guide, and design references

Changes made:
1. Kept the uploaded pages and JavaScript as the base.
2. Updated image paths to the required assets/ folder.
3. Changed avatar size validation to reject files at or above 500 KB.
4. Made the GitHub username on the ticket link to the matching GitHub profile.
5. Added examples of :is(), :where(), :not(), and :has() selectors.
6. Added a small float example for the information icon/text wrapping.
7. Added a glass-style border/background to the ticket container and keyboard focus-visible styling.

Before submitting:
- Open all three pages and test the registration workflow.
- Test empty fields, invalid email, GitHub handle without @, wrong file type, and an image that is 500 KB or larger.
- Check the GitHub link points to the right profile.
- Test mobile, tablet, and desktop sizes and take your own screenshots.
- Complete the PDF report with your own wireframe, student/assignment details, screenshots, sample test/login details, GitHub repository link, and free hosting link.
- Review every code change and make sure you can explain it. Follow your lecturer's AI-use and disclosure instructions.
- Rename the ZIP to the exact format requested by your lecturer, using your own student ID and name.
